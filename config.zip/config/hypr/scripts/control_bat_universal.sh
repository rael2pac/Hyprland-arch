#!/bin/bash

# Script Universal de Bateria (/sys/class/power_supply/)
# VERSÃO FINAL ESTÁVEL: Tooltip em LINHA ÚNICA com Ponto de Lista (•) para não travar.

EXCLUDE_PATTERNS="BAT[0-9]|AC|DisplayDevice"

DEVICE_COUNT=0
# Separador visual limpo e estável (Ponto de Lista)
SEPARATOR=" • " 

DEVICE_DETAILS="" 

# 1. Encontra e itera sobre todos os caminhos de bateria de dispositivos externos
for DEVICE_PATH in $(ls /sys/class/power_supply/ | grep -v -E "$EXCLUDE_PATTERNS" | grep -E 'battery|hid|controller'); do
    
    CAPACITY=$(cat /sys/class/power_supply/"$DEVICE_PATH"/capacity 2>/dev/null)
    
    # Verifica se a capacidade é um número válido e maior que zero
    if [[ "$CAPACITY" =~ ^[0-9]+$ ]] && [ "$CAPACITY" -gt 0 ]; then
        
        DEVICE_COUNT=$((DEVICE_COUNT + 1))
        
        # Formata o nome para o Tooltip
        DEVICE_NAME=$(echo "$DEVICE_PATH" | sed 's/hid-//; s/-battery//; s/_/ /g' | awk '{$1=toupper(substr($1,1,1))substr($1,2)}1')

        # Adiciona o dispositivo à lista com o separador
        DEVICE_DETAILS+="${DEVICE_NAME}: ${CAPACITY}%${SEPARATOR}"
    fi
done

# 2. Formata a Saída JSON

if [ "$DEVICE_COUNT" -gt 0 ]; then
    
    # Remove o último separador (Ponto de Lista)
    CLEAN_TOOLTIP=${DEVICE_DETAILS%${SEPARATOR}}
    
    # Monta a saída 'text' com APENAS O ÍCONE
    WAYBAR_TEXT="🎮"
    
    # Imprime o JSON de saída: usando printf para estabilidade
    printf '{"text": "%s", "tooltip": "%s"}\n' "$WAYBAR_TEXT" "$CLEAN_TOOLTIP"
else
    # Se zero dispositivos, retorna JSON vazio para esconder o módulo
    echo '{"text": "", "tooltip": ""}'
fi
