#!/bin/bash
#
# Nome do processo do OBS (ajuste para "obs-studio" se "obs" não funcionar)
OBS_PROCESS="obs"

# Arquivo que o script usa como "nota" para lembrar quem ligou o DND
STATE_FILE="/tmp/swaync_obs_auto_dnd_active"

while true; do
    # Verifica se o OBS ESTÁ RODANDO
    if pgrep -x "$OBS_PROCESS" > /dev/null; then
        
        # --- LIGA O DND E CRIA O ARQUIVO DE ESTADO ---
        
        # 1. Checa se o DND está LIGADO. Se não estiver, liga.
        # Isso garante que mesmo que você desligue manualmente enquanto o OBS está aberto, ele liga de novo.
        if ! swaync-client -D | grep -q 'true'; then
            echo "OBS detectado. Ativando DND (Automático)."
            swaync-client -dn
        fi
        
        # 2. Cria o arquivo de estado para assumir a responsabilidade.
        touch "$STATE_FILE"
        
    else
        # Verifica se o OBS NÃO ESTÁ RODANDO
        
        # --- DESLIGA O DND, MAS SÓ SE FOI O SCRIPT QUE LIGOU ---
        
        # Checa se o DND está LIGADO E se o arquivo de estado (nossa nota) existe.
        if swaync-client -D | grep -q 'true' && [ -f "$STATE_FILE" ]; then
            echo "OBS fechado. Desligando DND Automático."
            swaync-client -df  # Comando para desligar
            rm -f "$STATE_FILE" # Remove a nota. Agora o DND manual pode ser ligado sem interferência.
        fi
        
        # Se DND estiver ligado, mas o arquivo NÃO existir, significa que o DND é MANUAL e o script ignora.
    fi

    sleep 5 # Pausa de 5 segundos
done
