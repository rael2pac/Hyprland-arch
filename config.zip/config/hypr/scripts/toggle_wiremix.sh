#!/bin/bash

# Fecha se já estiver aberto
if hyprctl clients | grep -q "title: wiremix ~"; then
    # foca a janela do wiremix
    hyprctl dispatch focuswindow "title:wiremix ~"
    sleep 0.05
    
    # envia a tecla 'q' para ela (WireMix fecha com 'q')
    wtype -k q
    
    exit 0
fi

# Abre o wiremix dentro do kitty com título único
kitty --title "wiremix ~" -e wiremix &


