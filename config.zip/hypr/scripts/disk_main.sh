#!/bin/bash
# Script de Disco — Tooltip estável, com unidades em minúsculas (gb, mb)

MAIN_MOUNT="/"
EXCLUDED_TYPES="tmpfs|devtmpfs|squashfs|ramfs|overlay|cgroup|udev|proc|sys|securityfs|efivarfs|pstore"

# ÍCONES (Nerd Font)
ICON_MAIN="󰋊"  # Ícone padrão/principal
ICON_HOME="󰋜"  # Para /home
ICON_USB="󰦥"   # Para Mídia Removível
ICON_HDD="󰋇"   # Para Outros Discos/Partições
ICON_BOOT="󰻀"  # Para /boot

# Coleta de discos, removendo tipos indesejados
DISK_DATA=$(df -h -x tmpfs -x devtmpfs -x squashfs -x ramfs -x overlay -x cgroup2 -x proc -x sysfs -x udev -x pstore -x efivarfs 2>/dev/null | awk 'NR>1 {print $6, $3, $4, $2}')

# --- DISCO PRINCIPAL ---
MAIN_DATA=$(echo "$DISK_DATA" | awk -v M="$MAIN_MOUNT" '$1 == M {print $2, $3, $4}')
USED_MAIN=$(echo "$MAIN_DATA" | awk '{print $1}') 
FREE_MAIN=$(echo "$MAIN_DATA" | awk '{print $2}')
TOTAL_MAIN=$(echo "$MAIN_DATA" | awk '{print $3}')

# =========================================================
# 🔹 SUBSTITUIÇÃO DE UNIDADES (G -> gb, M -> mb) 🔹
# =========================================================

# Função para substituir a unidade curta pela unidade longa (minúscula)
format_unit() {
    local value="$1"
    # Substitui G por gb
    value="${value/G/Gb}"
    # Substitui M por mb
    value="${value/M/Mb}"
    # Substitui T por tb
    value="${value/T/Tb}"
    # Se o valor for menor que 1M (ex: 500K), df -h usa 'K'. Substituímos por 'kb'
    value="${value/K/Kb}"
    echo "$value"
}

# Aplica a formatação nas variáveis principais
USED_MAIN_LONG=$(format_unit "$USED_MAIN")
FREE_MAIN_LONG=$(format_unit "$FREE_MAIN")
TOTAL_MAIN_LONG=$(format_unit "$TOTAL_MAIN")

# Texto principal do Waybar: Apenas o valor (sem ICON_MAIN, já que você usa no módulo)
WAYBAR_TEXT="$USED_MAIN_LONG"

# --- TOOLTIP DO DISCO PRINCIPAL (Alinhamento Corrigido) ---
TOOLTIP="${ICON_MAIN} DISCO PRINCIPAL (${MAIN_MOUNT})\n"
TOOLTIP+="Usado : $USED_MAIN_LONG\n"
TOOLTIP+="Livre : $FREE_MAIN_LONG\n"
TOOLTIP+="Total : $TOTAL_MAIN_LONG\n\n"
TOOLTIP+="${ICON_MAIN} OUTROS DISCOS:\n"

# --- LOOP PARA OUTROS DISCOS ---
while read -r MOUNT USED FREE TOTAL; do
    [[ "$MOUNT" == "$MAIN_MOUNT" ]] && continue

    NAME=$(basename "$MOUNT")
    [[ -z "$NAME" ]] && NAME="$MOUNT"
    
    # Aplica a formatação DENTRO do loop para o tooltip
    USED_LONG=$(format_unit "$USED")
    TOTAL_LONG=$(format_unit "$TOTAL")

    # Sua lógica de ícones personalizada
    if [[ "$MOUNT" == "/home" ]]; then
        ICON="$ICON_HOME"
    elif [[ "$MOUNT" == "/boot" ]]; then
        ICON="$ICON_BOOT"
    elif [[ "$MOUNT" == *"run/media"* ]]; then
        ICON="${ICON_USB}" # Mudando para ICON_USB para ser mais descritivo
    else
        ICON="${ICON_HDD}" # Mudando para ICON_HDD para ser mais descritivo
    fi

    # Linha final do Tooltip (usando as variáveis formatadas)
    TOOLTIP+="${ICON} ${NAME}: ${USED_LONG}/${TOTAL_LONG}\n"
done <<< "$DISK_DATA"

# --- ESCAPA PARA JSON (Método Simples e Confiável) ---
ESCAPED_TOOLTIP=$(echo "$TOOLTIP" | sed ':a;N;$!ba;s/\n/\\n/g; s/"/\\"/g' | tr -d '\r')

# --- SAÍDA FINAL (Sem Pango - Máxima Estabilidade) ---
echo "{\"text\": \"$WAYBAR_TEXT\", \"tooltip\": \"$ESCAPED_TOOLTIP\"}"