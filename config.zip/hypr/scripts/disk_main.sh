#!/bin/bash

# Script de Disco: Tooltip Elegante com Quebras de Linha (\n) e Saída Minimalista

MAIN_MOUNT="/"
EXCLUDED_TYPES="tmpfs|devtmpfs|squashfs|ramfs|overlay|cgroup|udev|proc|sys|securityfs|efivarfs|pstore"
SEPARATOR=" • " 

# --- 1. COLETA DADOS DO DISCO PRINCIPAL (/) ---
MAIN_DATA_GB=$(df -BG "$MAIN_MOUNT" 2>/dev/null | awk 'NR==2 {
    used=$3; total=$2; avail=$4;
    # Remove o 'G' do final dos valores
    gsub("G$", "", used); gsub("G$", "", total); gsub("G$", "", avail); 
    
    # Imprime apenas os valores numéricos em GB
    print used, avail, total
}')

# Separa os campos lidos
USED_GB=$(echo "$MAIN_DATA_GB" | awk '{print $1}')
FREE_GB=$(echo "$MAIN_DATA_GB" | awk '{print $2}')
TOTAL_GB=$(echo "$MAIN_DATA_GB" | awk '{print $3}')

# NOVO: Define o texto minimalista para a Waybar: APENAS o uso com a unidade.
WAYBAR_TEXT="${USED_GB}Gb"

# --- 2. MONTA TOOLTIP: DISCO PRINCIPAL (Elegante com \n) ---
TOOLTIP_STRING="DISCO PRINCIPAL (/)\n"
TOOLTIP_STRING+="  Usada - ${USED_GB}Gb\n"
TOOLTIP_STRING+="  Livre - ${FREE_GB}Gb\n"
TOOLTIP_STRING+="  Total - ${TOTAL_GB}Gb"

# --- 3. COLETA E ADICIONA DISCOS SECUNDÁRIOS ---
OTHER_DISKS_DETAIL=""
SEPARATOR="\n" 

df -BG -x "$EXCLUDED_TYPES" 2>/dev/null | awk 'NR>1 && $6 != "'"$MAIN_MOUNT"'" {
    mount_point = $6; used=$3; total=$2;
    gsub("G$", "", used); gsub("G$", "", total); 
    name = ($6 == "/home" ? "Home" : substr($6, match($6, /[^/]*$/)));
    print name ": " used "G/" total "G"
}' | while IFS= read -r LINE; do
    OTHER_DISKS_DETAIL+="${SEPARATOR}${LINE}"
done

if [ -n "$OTHER_DISKS_DETAIL" ]; then
    TOOLTIP_STRING+="\n\nPARTIÇÕES SECUNDÁRIAS:"
    TOOLTIP_STRING+="$OTHER_DISKS_DETAIL"
fi

# --- 4. SAÍDA JSON FINAL ---
# Usa o mesmo método de ESCAPE que funcionou no módulo de memória
ESCAPED_TOOLTIP=$(echo "$TOOLTIP_STRING" | sed ':a;N;$!ba;s/\n/\\n/g')

# O 'text' da Waybar agora é APENAS o uso em GB
echo "{\"text\": \"$WAYBAR_TEXT\", \"tooltip\": \"$ESCAPED_TOOLTIP\"}"
