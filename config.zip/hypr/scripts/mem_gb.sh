#!/bin/bash

# Script para Memória: Saída JSON Minimalista e Tooltip Detalhado

CONV_FACTOR=1048576

# Funções de arredondamento...
round_to_int() {
    echo "scale=0; $1 / $CONV_FACTOR" | bc | awk '{printf "%d", $1 + 0.5}'
}
get_nominal_total() {
    local total_kb=$1
    local total_gb_int=$(echo "scale=0; $total_kb / $CONV_FACTOR" | bc)
    if [ "$total_gb_int" -ge 30 ] && [ "$total_gb_int" -le 34 ]; then
        echo "32"
    else
        round_to_int $total_kb
    fi
}

# 1. Obtém e calcula
MEM_TOTAL_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
MEM_AVAIL_KB=$(grep MemAvailable /proc/meminfo | awk '{print $2}')
MEM_USED_KB=$((MEM_TOTAL_KB - MEM_AVAIL_KB))

MEM_TOTAL_GB=$(get_nominal_total $MEM_TOTAL_KB) 
MEM_USED_GB=$(round_to_int $MEM_USED_KB)
MEM_FREE_GB=$(round_to_int $MEM_AVAIL_KB)

# 2. Calcula Porcentagem
MEM_USED_PERC=$(echo "scale=1; ($MEM_USED_KB * 100) / $MEM_TOTAL_KB" | bc)

# 3. Monta o Tooltip ELEGANTEMENTE com \n (sem a letra G nos valores)
TOOLTIP_STRING="Uso:  - ${MEM_USED_PERC}%\n"
TOOLTIP_STRING+="Usada - ${MEM_USED_GB}Gb\n"
TOOLTIP_STRING+="Livre - ${MEM_FREE_GB}Gb\n"
TOOLTIP_STRING+="Total - ${MEM_TOTAL_GB}Gb"

# 4. Escapa a quebra de linha (\n)
ESCAPED_TOOLTIP=$(echo "$TOOLTIP_STRING" | sed ':a;N;$!ba;s/\n/\\n/g')

# 5. Saída JSON FINAL: O campo 'text' agora é APENAS o número usado.
#MAIN_TEXT="${MEM_USED_GB}"
MAIN_TEXT="${MEM_USED_GB}Gb/${MEM_TOTAL_GB}"

# 6. Imprime o JSON de saída
printf '{"text": "%s", "tooltip": "%s"}\n' "$MAIN_TEXT" "$ESCAPED_TOOLTIP"
