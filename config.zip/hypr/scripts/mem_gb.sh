#!/bin/bash

# Script Universal para Memória com Arredondamento para Cima no Total (Ceil)

# Constante de conversão (KB para GB)
CONV_FACTOR=1048576

# Função 1: Arredondamento para CIMA (Ceil)
# Garante que 15.1Gb, 15.6Gb, etc., sejam exibidos como 16Gb.
ceil_gb() {
    # Usa BC para calcular a divisão, verifica se há decimal (resto > 0)
    # e arredonda para cima.
    echo "scale=0; ($1 + $CONV_FACTOR - 1) / $CONV_FACTOR" | bc
}

# Função 2: Arredondamento para o Inteiro Mais Próximo
# Usado para Usada e Livre, para maior precisão de exibição.
round_to_nearest_int() {
    echo "scale=0; ($1 / $CONV_FACTOR) + 0.5" | bc | cut -d'.' -f1
}

# 1. Obter e Tratar Erro
MEM_TOTAL_KB=$(grep MemTotal /proc/meminfo 2>/dev/null | awk '{print $2}')
MEM_AVAIL_KB=$(grep MemAvailable /proc/meminfo 2>/dev/null | awk '{print $2}')

if [ -z "$MEM_TOTAL_KB" ] || [ -z "$MEM_AVAIL_KB" ]; then
    printf '{"text": "ERRO", "tooltip": "Falha ao ler /proc/meminfo. Ambiente incompatível."}\n'
    exit 1
fi

MEM_USED_KB=$((MEM_TOTAL_KB - MEM_AVAIL_KB))

# 2. Arredondamento
# TOTAL: Usa a função CEIL para garantir 16Gb
MEM_TOTAL_GB=$(ceil_gb $MEM_TOTAL_KB) 

# USADA e LIVRE: Usa o arredondamento normal para o inteiro mais próximo.
MEM_USED_GB=$(round_to_nearest_int $MEM_USED_KB)
MEM_FREE_GB=$(round_to_nearest_int $MEM_AVAIL_KB)

# 3. Calcula Porcentagem (Usa os valores KB reais para precisão)
MEM_USED_PERC=$(echo "scale=1; ($MEM_USED_KB * 100) / $MEM_TOTAL_KB" | bc)

# 4. Monta o Tooltip ELEGANTEMENTE com \n (Usando valores de inteiro)
TOOLTIP_STRING="Uso:  - ${MEM_USED_PERC}%\n"
TOOLTIP_STRING+="Usada - ${MEM_USED_GB}Gb\n"
TOOLTIP_STRING+="Livre - ${MEM_FREE_GB}Gb\n"
TOOLTIP_STRING+="Total - ${MEM_TOTAL_GB}Gb"

# 5. Escapa a quebra de linha (\n)
ESCAPED_TOOLTIP=$(printf "%s" "$TOOLTIP_STRING" | sed 's/\n/\\n/g')

# 6. Saída JSON FINAL:
MAIN_TEXT="${MEM_USED_GB}Gb/${MEM_TOTAL_GB}"

# 7. Imprime o JSON de saída
printf '{"text": "%s", "tooltip": "%s"}\n' "$MAIN_TEXT" "$ESCAPED_TOOLTIP"