#!/bin/bash

# Define o Dolphin como gerenciador padrão para abrir pastas
xdg-mime default org.kde.dolphin.desktop inode/directory

# Garante que o sistema Wayland reconheça a mudança imediatamente
update-desktop-database ~/.local/share/applications
