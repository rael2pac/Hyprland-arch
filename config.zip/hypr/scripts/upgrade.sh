#!/bin/bash
# Script de atualização do sistema Arch Linux + AUR + Hyprland
# VERSÃO FINAL: Atualiza, limpa o sistema silenciosamente, exibe log colorido, pedindo senha apenas 1x.

STATE_FILE="$HOME/.cache/waybar_updates_state"
PACMAN_PRE_UPDATE=$(checkupdates 2>/dev/null || true)
AUR_PRE_UPDATE=$(yay -Qqum 2>/dev/null || true)
LOG_FILE=$(mktemp)
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
CYAN='\033[0;36m'
NC='\033[0m'

set -euo pipefail

# 🔹 Pré-autentica sudo (uma senha no início)
sudo -v
# Mantém cache sudo ativo durante todo o script
while true; do sudo -n true; sleep 60; kill -0 "$$" || exit; done 2>/dev/null &

notify-send "Atualização do Sistema" "Iniciando atualização (Pacman + AUR)..."
echo -e "${YELLOW}Iniciando a atualização do sistema...${NC}"
echo "-------------------------------------"

cleanup_on_error() {
    echo "-------------------------------------"
    echo -e "${RED}❌ ERRO FATAL: Falha durante a atualização. Verifique o terminal para detalhes.${NC}"
    rm -f "$LOG_FILE"
    exit 1
}
trap cleanup_on_error ERR

# ==============================================================
echo -e "-> ${CYAN}1. Atualizando Pacman + AUR e limpando cache/órfãos...${NC}"

sudo bash <<'EOF'
RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
NC='\033[0m'

# Atualização Pacman + AUR
echo -e "\n${CYAN}-> Atualizando Pacman e AUR...${NC}"
script -qc "yay -Syu --noconfirm"

# Limpeza do cache do Pacman
echo -e "\n${CYAN}-> Limpando cache do Pacman (mantendo 3 versões)...${NC}"
paccache -r -k 3

# Remove pacotes órfãos
orphans=$(pacman -Qtdq 2>/dev/null)
if [ -n "$orphans" ]; then
    echo -e "\n${CYAN}Pacotes órfãos encontrados:${NC}"
    pacman -Rns --noconfirm $orphans
else
    echo "Nenhum pacote órfão encontrado."
fi
EOF

# Limpeza do cache do usuário (ignora pastas importantes)
echo -e "\n${CYAN}-> Limpando ~/.cache (ignorando pastas importantes)...${NC}"
find "$HOME/.cache" -mindepth 1 -maxdepth 1 \
  ! -name "waybar" \
  ! -name "Hyprland" \
  ! -name "fontconfig" \
  ! -name "dolphin" \
  ! -name "wofi-drun" \
  ! -name "thumbnails" \
  ! -name "lutris" \
  ! -name "waypaper" \
  -exec rm -rf {} + 2>/dev/null || true

# ==============================================================
rm -f "$STATE_FILE"
pkill -SIGRTMIN+8 waybar || true

if pgrep -x "Hyprland" > /dev/null; then
    hyprctl reload
fi

# ==============================================================
echo "-------------------------------------"
notify-send "Atualização do Sistema CONCLUÍDA" "Sistema atualizado com sucesso!"

echo -e "${GREEN}✅ Sistema atualizado com sucesso!${NC}"
echo ""
echo "================================================="
echo -e "${CYAN}LOG DE PACOTES ATUALIZADOS (Pacman & AUR):${NC}"
echo "================================================="

if [[ -z "$PACMAN_PRE_UPDATE" && -z "$AUR_PRE_UPDATE" ]]; then
    echo "Nenhuma atualização foi detectada antes da execução."
else
    if [[ -n "$PACMAN_PRE_UPDATE" ]]; then
        echo -e "${CYAN}--- Pacman ---${NC}"
        echo "$PACMAN_PRE_UPDATE" | awk -v G="$GREEN" -v C="$NC" '{ print G $0 C }'
    fi
    if [[ -n "$AUR_PRE_UPDATE" ]]; then
        echo -e "\n${CYAN}--- AUR ---${NC}"
        echo "$AUR_PRE_UPDATE" | awk -v G="$GREEN" -v C="$NC" '{ print G $0 C }'
    fi
fi
echo "================================================="
echo ""

rm -f "$LOG_FILE"

echo "Pressione Enter para fechar o terminal e continuar."
read -r

if [ "${KITTY_WINDOW_ID:-}" ]; then
    kitty @ close-window
else
    exit
fi
