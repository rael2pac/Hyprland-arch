#!/bin/bash
# Script de atualização do sistema Arch Linux + Flatpak + Hyprland
# Autor: Rael
# Adaptação para Arch por ChatGPT
# Este script atualiza pacotes do Arch, Flatpaks, plugins do Hyprland
# e envia notificações para o swaync/Waybar.

# 🔹 Ativa o "modo estrito" do Bash
set -euo pipefail

# 🔹 Envia notificação inicial
notify-send "Atualização do Sistema" "Iniciando a atualização do sistema..."
echo "Iniciando a atualização do sistema..."

# ==============================================================
# 🔹 PARTE ROOT (necessita sudo)
# ==============================================================

sudo bash -c '
  # Atualiza pacotes do sistema base (pacman)
  pacman -Syu --noconfirm

  # Remove pacotes órfãos apenas se existirem
  orphans=$(pacman -Qtdq)
  if [ -n "$orphans" ]; then
      pacman -Rns $orphans --noconfirm
  fi
'

# ==============================================================
# 🔹 PARTE USUÁRIO (NÃO usar sudo)
# ==============================================================

# Atualiza pacotes AUR e do sistema com yay (não precisa sudo)
yay -Syu --noconfirm

# Atualiza Flatpaks
#flatpak update -y

# Remove runtimes Flatpak não utilizados
#flatpak uninstall --unused -y

# Atualiza plugins do Hyprland (caso use hyprpm)
hyprpm update || true

# ==============================================================
# 🔹 Pós-atualização
# ==============================================================

# Envia notificação de conclusão
notify-send "Atualização do Sistema" "Sistema atualizado com sucesso!"

# Reinicia módulos da Waybar (ex: contador de updates)
pkill -SIGRTMIN+8 waybar || true

# Recarrega configuração do Hyprland
hyprctl reload

# ==============================================================
# 🔹 Mensagem final
# ==============================================================

echo "Sistema atualizado com sucesso!"
echo "Pressione Enter para fechar..."
read -r

# Fecha automaticamente a janela se estiver no terminal Kitty
if [ "${KITTY_WINDOW_ID:-}" ]; then
    kitty @ close-window
else
    exit
fi
