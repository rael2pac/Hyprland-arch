#!/bin/bash
# Script de atualização do sistema Arch Linux + AUR + Hyprland
# VERSÃO FINAL: Atualiza, limpa o sistema silenciosamente, e exibe o log completo colorido.

# --------------------------------------------------------------------------
# VARIÁVEIS E ARQUIVOS CRÍTICOS
# --------------------------------------------------------------------------
STATE_FILE="$HOME/.cache/waybar_updates_state"
# Nomes dos pacotes antes da atualização (usados apenas para a mensagem final de log)
PACMAN_PRE_UPDATE=$(checkupdates 2>/dev/null || true)
AUR_PRE_UPDATE=$(yay -Qqum 2>/dev/null || true)
LOG_FILE=$(mktemp) # Arquivo temporário para salvar o LOG
# Códigos de cor ANSI para o terminal
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# 🔹 Ativa o "modo estrito" do Bash.
set -euo pipefail

# 🔹 Envia notificação inicial
notify-send "Atualização do Sistema" "Iniciando a atualização do sistema (Pacman e AUR)..."
echo -e "${YELLOW}Iniciando a atualização do sistema...${NC}"
echo "-------------------------------------"

# Função de limpeza e tratamento de erro
cleanup_on_error() {
    echo "-------------------------------------"
    echo -e "${RED}❌ ERRO FATAL: Falha durante a atualização. Verifique o terminal para detalhes.${NC}"
    rm -f "$LOG_FILE"
    exit 1
}

# Garante que a função cleanup_on_error seja executada se algum comando falhar.
trap cleanup_on_error ERR

# ==============================================================
# 🔹 PARTE PRINCIPAL (Atualização e Cores)
# ==============================================================

echo -e "-> ${CYAN}1. Atualizando Pacman e AUR com Yay...${NC}"

# CORREÇÃO: Usa 'script -qc' para forçar a saída colorida do yay/pacman no terminal.
# O log ainda é capturado para fins de erro, mas a saída no terminal é colorida.
script -qc "yay -Syu --noconfirm" "$LOG_FILE" || true


# ==============================================================
# 🔹 Limpeza Completa do Sistema (Silenciosa)
# ==============================================================

echo -e "-> ${CYAN}2. Removendo órfãos e limpando cache (Silencioso)...${NC}"
# Executa a limpeza dentro de um bloco sudo para garantir privilégios,
# e redireciona todo o output para /dev/null para evitar quebrar as cores.
sudo bash -c '
  # Limpa o cache do Pacman: mantém as 3 últimas versões de cada pacote.
  paccache -r -k 3 >/dev/null 2>&1 || true
  
  # Remove pacotes órfãos (dependências não mais necessárias).
  orphans=$(pacman -Qtdq 2>/dev/null)
  if [ -n "$orphans" ]; then
      pacman -Rns $orphans --noconfirm >/dev/null 2>&1
  fi
'
echo -e "${GREEN}Limpeza de sistema concluída.${NC}"


# ==============================================================
# 🔹 Ações de Sincronização e Pós-atualização
# ==============================================================

echo -e "-> ${CYAN}3. Atualizando plugins do Hyprland (hyprpm)...${NC}"
if command -v hyprpm >/dev/null 2>&1; then
    hyprpm update || true
else
    echo "Hyprpm não encontrado ou não configurado. Pulando."
fi

# LIMPEZA CRÍTICA: Zera o contador de updates.
rm -f "$STATE_FILE"

# 1. Envia sinal para a Waybar (atualiza o contador para 0)
pkill -SIGRTMIN+8 waybar || true

# 2. Recarrega configuração do Hyprland
if pgrep -x "Hyprland" > /dev/null; then
    hyprctl reload
fi

# ==============================================================
# 🔹 Mensagem final (Para a janela do terminal)
# ==============================================================

echo "-------------------------------------"
notify-send "Atualização do Sistema CONCLUÍDA" "Sistema atualizado com sucesso!"

echo -e "${GREEN}✅ Sistema atualizado com sucesso!${NC}"
echo ""
echo "================================================="
echo -e "${CYAN}LOG DE PACOTES ATUALIZADOS (Pacman & AUR):${NC}"
echo "================================================="

# Exibe os pacotes que estavam disponíveis ANTES da atualização
if [[ -z "$PACMAN_PRE_UPDATE" && -z "$AUR_PRE_UPDATE" ]]; then
    echo "Nenhuma atualização foi detectada antes da execução."
else
    # Exibe Pacman 
    if [[ -n "$PACMAN_PRE_UPDATE" ]]; then
        echo -e "${CYAN}--- Pacman ---${NC}"
        # Apenas colorir o texto verde
        echo "$PACMAN_PRE_UPDATE" | awk -v G="$GREEN" -v C="$NC" '
            { print G $0 C }
        '
    fi
    # Exibe AUR
    if [[ -n "$AUR_PRE_UPDATE" ]]; then
        echo -e "\n${CYAN}--- AUR ---${NC}"
        # Apenas colorir o texto verde
        echo "$AUR_PRE_UPDATE" | awk -v G="$GREEN" -v C="$NC" '
            { print G $0 C }
        '
    fi
fi
echo "================================================="
echo ""

# Limpa o arquivo de log temporário antes de fechar
rm -f "$LOG_FILE"

echo "Pressione Enter para fechar o terminal e continuar."
read -r

# Fecha automaticamente a janela do Kitty
if [ "${KITTY_WINDOW_ID:-}" ]; then
    kitty @ close-window
else
    exit
fi