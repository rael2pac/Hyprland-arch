#!/bin/bash

# Ajusta volume
pamixer "$@"

# Pega volume atual
VOL=$(pamixer --get-volume)
MUTE=$(pamixer --get-mute)

if [ "$MUTE" = "true" ]; then
    notify-send -a "OSD" -t 1000 \
        -h string:x-canonical-private-synchronous:volume \
        -h int:value:0 \
        "🔇 Volume" "Mudo"
else
    notify-send -a "OSD" -t 1000 \
        -h string:x-canonical-private-synchronous:volume \
        -h int:value:"$VOL" \
        "🔊 Volume" "${VOL}%"
fi
