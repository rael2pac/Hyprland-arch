#!/bin/bash
# Script Final, Robusto e Plus para checagem de atualizações no Arch (Pacman + AUR)

# ----------------------------------------------------------------------
# ATENÇÃO: Para zerar o contador após a atualização, seu script de upgrade
# deve DELETAR o arquivo $STATE_FILE e enviar um sinal para a Waybar.
# ----------------------------------------------------------------------

# Estado e Cache de Arquivos
STATE_FILE="$HOME/.cache/waybar_updates_state"
CACHE_JSON="$HOME/.cache/waybar_updates.json" 
mkdir -p "$(dirname "$STATE_FILE")"

# --- Funções de utilidade ---
# ROBUSTEZ: Mostra o último estado válido (cache) se a checagem falhar.
show_cache_and_exit() {
    if [[ -f "$CACHE_JSON" ]]; then
        cat "$CACHE_JSON"
        exit 0
    else
        # Saída padrão de erro limpa
        jq -nc --arg text "0" --arg tooltip "Nenhuma atualização disponível (Cache indisponível)" \
           '{text: $text, tooltip: $tooltip}'
        exit 0
    fi
}

# --- Coletar pacotes ---
pacman_list=$(checkupdates 2>/dev/null || true)
aur_list=$(yay -Qum 2>/dev/null || true)

pacman_count=$(echo "$pacman_list" | grep -v '^$' | wc -l)
aur_count=$(echo "$aur_list" | grep -v '^$' | wc -l)
count=$((pacman_count + aur_count))

# Carregar último estado salvo
last_count=0
[[ -f "$STATE_FILE" ]] && last_count=$(cat "$STATE_FILE")

# LÓGICA DE ROBUSTEZ:
# Se o COUNT for 0, mas o LAST_COUNT não era 0 (e o STATE_FILE existe),
# assumimos falha temporária (rede, etc.) e mantemos o contador antigo.
# Isso é ignorado se o STATE_FILE foi apagado (após um upgrade).
if [[ $count -eq 0 && $last_count -gt 0 ]]; then
    show_cache_and_exit
fi

# Salvar novo estado
echo "$count" > "$STATE_FILE"

# --- Construir tooltip (Contador exato e lista de pacotes) ---
if [[ $count -gt 0 ]]; then
    summary="<span color='#7aa2f7'>Pacman: $pacman_count</span> | <span color='#e0af68'>AUR: $aur_count</span> | <span color='#ffffff'>Total: $count</span>"
    tooltip="Atualizações disponíveis:
$summary"

    if [[ $pacman_count -gt 0 ]]; then
        tooltip+="
<span color=\"#00000000\">──────────────</span>
<span color=\"#7aa2f7\">== Pacman ==</span>"
        # Lista Pacman (limitada a 15)
        pacman_trunc=$(echo "$pacman_list" | head -n15 | sed -E \
            "s/^(\S+)\s+(\S+)\s+(\S+)/<span color='#f7768e'>\1<\/span> <span color='#7aa2f7'>\2<\/span> <span color='#9ece6a'>\3<\/span>/")
        tooltip+="
$pacman_trunc"
        [[ $pacman_count -gt 15 ]] && tooltip+="
<span color=\"#565f89\">… e mais $((pacman_count-15)) pacotes</span>"
    fi

    if [[ $aur_count -gt 0 ]]; then
        tooltip+="
<span color=\"#00000000\">──────────────</span>
<span color=\"#e0af68\">== AUR ==</span>"
        # Lista AUR (limitada a 15)
        aur_trunc=$(echo "$aur_list" | head -n15 | sed -E \
            "s/^(\S+)/<span color='#f7768e'>\1<\/span>/")
        tooltip+="
$aur_trunc"
        [[ $aur_count -gt 15 ]] && tooltip+="
<span color=\"#565f89\">… e mais $((aur_count-15)) pacotes</span>"
    fi
else
    tooltip="Nenhuma atualização disponível"
fi

# --- Notificação: Só dispara se o número de updates mudar (e não há throttle) ---
if [[ $count -gt 0 && $count -ne $last_count ]]; then
    
    # 1. TÍTULO: Usa "10+" se count >= 10
    if [[ $count -ge 10 ]]; then
        notify_title="Atualizações disponíveis: 10+ pacotes"
    else
        notify_title="Atualizações disponíveis: $count pacotes"
    fi
    
    # 2. CORPO: Lista os nomes dos pacotes (limitado a 5 de cada)
    notify_body=""
    
    if [[ $pacman_count -gt 0 ]]; then
        pacman_names=$(echo "$pacman_list" | head -n5 | awk '{print $1}')
        notify_body+="== Pacman (${pacman_count}) ==\n${pacman_names}"
        if [[ $pacman_count -gt 5 ]]; then
            notify_body+="\n... e mais $((pacman_count-5)) pacotes"
        fi
    fi
    
    if [[ $aur_count -gt 0 ]]; then
        if [[ $pacman_count -gt 0 ]]; then
            notify_body+="\n\n"
        fi
        
        aur_names=$(echo "$aur_list" | head -n5 | awk '{print $1}')
        notify_body+="== AUR (${aur_count}) ==\n${aur_names}"
        if [[ $aur_count -gt 5 ]]; then
            notify_body+="\n... e mais $((aur_count-5)) pacotes"
        fi
    fi
    
    # 3. Enviar a notificação
    notify-send "$notify_title" "$notify_body" -i system-software-update
fi

# --- JSON final: Waybar mostra o $count exato ---
json=$(jq -nc --arg text "$count" --arg tooltip "$tooltip" \
   '{text: $text, tooltip: $tooltip}')

# Salva o JSON para a função de robustez
echo "$json" | tee "$CACHE_JSON"