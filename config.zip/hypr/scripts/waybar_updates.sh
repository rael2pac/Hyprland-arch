#!/bin/bash
# Script robusto para checagem de atualizações no Arch (Pacman + AUR)
# VERSÃO FINAL (ZERO GARANTIDO): Corrige o erro do contador "1" persistente.

# ----------------------------------------------------------------
# BLOQUEIO (LOCKING) - Garante consistência em múltiplos monitores
# ----------------------------------------------------------------
LOCK_FILE="/tmp/waybar_updates.lock"

# ESTE PARÊNTESE ABRE O BLOCO DE BLOQUEIO
(
    # Tenta obter o bloqueio por no máximo 30 segundos. Se falhar, o script termina.
    flock -w 30 9 || exit 1 

    # ----------------------------------------------------------------
    # VARIÁVEIS DE ESTADO E CACHE
    # ----------------------------------------------------------------

    STATE_FILE="$HOME/.cache/waybar_updates_state"
    CACHE_JSON="$HOME/.cache/waybar_updates.json" 
    
    # Arquivo: Lista dos pacotes da última notificação enviada (para notificação focada)
    LAST_NOTIFIED_LIST="$HOME/.cache/waybar_updates_notified_list"
    
    mkdir -p "$(dirname "$STATE_FILE")"

    # --- Funções de utilidade ---
    show_cache_and_exit() {
        if [[ -f "$CACHE_JSON" ]]; then
            cat "$CACHE_JSON"
            exit 0
        else
            jq -nc --arg text "0" --arg tooltip "Nenhuma atualização disponível (Cache indisponível)" \
               '{text: $text, tooltip: $tooltip}'
            exit 0
        fi
    }

    # --- Coletar pacotes ---
    # 1. Comando de limpeza universal: Força ASCII e limpa lixo.
    CLEAN_PIPE="iconv -c -f utf-8 -t ascii 2>/dev/null | sed 's/\x1b\[[0-9;]*m//g;s/\r//g;s/^[[:space:]]*//;s/[[:space:]]*$//'"

    # 2. Captura Pacman: Filtra a saída para reter APENAS linhas com conteúdo (awk 'NF') na variável.
    pacman_output=$(checkupdates 2>/dev/null | eval "$CLEAN_PIPE" || true)
    pacman_list=$(echo "$pacman_output" | awk 'NF' || true)
    
    # 3. Captura AUR: Filtra a saída para reter APENAS linhas com conteúdo.
    aur_output=$(yay -Qua 2>/dev/null | eval "$CLEAN_PIPE" || true)
    aur_list=$(echo "$aur_output" | awk 'NF' || true)
    
    # 4. Combina as listas.
    current_list=$(echo -e "${pacman_list}\n${aur_list}" | awk 'NF' || true)

    # 5. Contagem inicial.
    pacman_count=$(echo "$pacman_list" | wc -l)
    aur_count=$(echo "$aur_list" | wc -l)
    count=$(echo "$current_list" | wc -l) # Contagem total

    # --- LÓGICA DE ZERO GARANTIDO (CORREÇÃO FINAL) ---
    # Se a contagem for 1, mas o tamanho da string for muito pequeno (não é um pacote real), 
    # assumimos que é lixo injetado no shell e forçamos o zero.
    if [[ $count -eq 1 && $(echo -n "$current_list" | wc -c) -lt 5 ]]; then
        count=0
        current_list=""
        pacman_list=""
        aur_list=""
    fi
    # -------------------------------------------------

    # Carregar último estado salvo
    last_count=0
    [[ -f "$STATE_FILE" ]] && last_count=$(cat "$STATE_FILE")

    # Salvar novo estado
    echo "$count" > "$STATE_FILE"

    # ----------------------------------------------------------------
    # --- Construir tooltip (Lógica COMPLETA para a Waybar) ---
    # ----------------------------------------------------------------
    
    if [[ $count -gt 0 ]]; then
        summary="<span color='#7aa2f7'>Pacman: $pacman_count</span> | <span color='#e0af68'>AUR: $aur_count</span> | <span color='#ffffff'>Total: $count</span>"
        tooltip="Atualizações disponíveis:
$summary"

        if [[ $pacman_count -gt 0 ]]; then
            tooltip+="
<span color=\"#00000000\">──────────────</span>
<span color=\"#7aa2f7\">== Pacman ==</span>"
            pacman_trunc=$(echo "$pacman_list" | head -n15 | sed -E \
                "s/^(\S+)\s+(\S+)\s+(\S+)/<span color='#f7768e'>\1<\/span> <span color='#7aa2f7'>\2<\/span> <span color='#9ece6a'>\3<\/span>/")
            tooltip+="
$pacman_trunc"
            [[ $pacman_count -gt 15 ]] && tooltip+="
<span color=\"#565f89\">… e mais $((pacman_count-15)) pacotes</span>"
        fi

        if [[ $aur_count -gt 0 ]]; then
            tooltip+="
<span color=\"#00000000\">──────────────</span>
<span color=\"#e0af68\">== AUR ==</span>"
            aur_trunc=$(echo "$aur_list" | head -n15 | sed -E \
                "s/^(\S+)\s+(\S+)\s+(\S+)/<span color='#f7768e'>\1<\/span> <span color='#7aa2f7'>\2<\/span> <span color='#9ece6a'>\3<\/span>/")
            tooltip+="
$aur_trunc"
            [[ $aur_count -gt 15 ]] && tooltip+="
<span color=\"#565f89\">… e mais $((aur_count-15)) pacotes</span>"
        fi
    else
        tooltip="Nenhuma atualização disponível"
    fi


    # ----------------------------------------------------------------
    # --- Notificação: LIMPA (SEM NÚMERO NO TÍTULO) ---
    # ----------------------------------------------------------------

    # 1. Carrega a lista de pacotes notificados na última vez
    last_notified_list=""
    [[ -f "$LAST_NOTIFIED_LIST" ]] && last_notified_list=$(cat "$LAST_NOTIFIED_LIST")

    # 2. Compara a lista atual com a última lista notificada para encontrar novos
    new_updates=$(echo "$current_list" | grep -vxFf <(echo "$last_notified_list") || true)
    
    new_count=$(echo "$new_updates" | grep -v '^$' | wc -l)

    # Verifica se há novos pacotes E se o total de pacotes não é zero.
    if [[ $new_count -gt 0 && $count -gt 0 ]]; then
        
        # TÍTULO LIMPO: APENAS O FATO DE HAVER UPDATES
        notify_title="Atualizações disponíveis"
        
        notify_body=""
        
        # CORPO: Listagem dos pacotes
        
        if [[ $pacman_count -gt 0 ]]; then
            # Pega 5 linhas completas de Pacman (Nome e Versão)
            pacman_trunc=$(echo "$pacman_list" | head -n5)
            notify_body+="== Pacman ($pacman_count) ==\n${pacman_trunc}"
            if [[ $pacman_count -gt 5 ]]; then
                notify_body+="\n... e mais $((pacman_count-5)) pacotes"
            fi
        fi
        
        if [[ $aur_count -gt 0 ]]; then
            if [[ $pacman_count -gt 0 ]]; then
                notify_body+="\n\n"
            fi
            
            # Pega 5 linhas completas de AUR (Nome)
            aur_trunc=$(echo "$aur_list" | head -n5)
            notify_body+="== AUR ($aur_count) ==\n${aur_trunc}"
            if [[ $aur_count -gt 5 ]]; then
                notify_body+="\n... e mais $((aur_count-5)) pacotes"
            fi
        fi

        # Envia a notificação
        notify-send "$notify_title" "$notify_body" -i system-software-update
        
        # 4. ATUALIZA O LOG
        echo "$current_list" > "$LAST_NOTIFIED_LIST"

    # Lógica de Correção: Se a contagem zerou (após um upgrade), limpa o log de notificação.
    elif [[ $count -eq 0 && $last_count -gt 0 ]]; then
        rm -f "$LAST_NOTIFIED_LIST"
    fi
    
    # --- JSON final: Waybar mostra o $count exato ---
    json=$(jq -nc --arg text "$count" --arg tooltip "$tooltip" \
       '{text: $text, tooltip: $tooltip}')

    # Salva o JSON para uso da função de robustez
    echo "$json" | tee "$CACHE_JSON"

# ESTA LINHA FECHA O BLOCO DE BLOQUEIO E É ESSENCIAL
) 9>"$LOCK_FILE"