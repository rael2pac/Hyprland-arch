#!/bin/bash
# Script robusto para checagem de atualizações no Arch (Pacman + AUR)
# Mostra JSON para Waybar com tooltip colorido e esteticamente agradável

STATE_FILE="$HOME/.cache/waybar_updates_state"
CACHE_JSON="$HOME/.cache/waybar_updates.json"
mkdir -p "$(dirname "$STATE_FILE")"

# Reaproveitar JSON se gerado há menos de 2 minutos
if [[ -f "$CACHE_JSON" && $(($(date +%s) - $(stat -c %Y "$CACHE_JSON"))) -lt 120 ]]; then
    cat "$CACHE_JSON"
    exit 0
fi

# --- Coletar pacotes ---
pacman_list=$(checkupdates 2>/dev/null || true)
aur_list=$(yay -Qum 2>/dev/null || true)

pacman_count=$(echo "$pacman_list" | grep -v '^$' | wc -l)
aur_count=$(echo "$aur_list" | grep -v '^$' | wc -l)
count=$((pacman_count + aur_count))

# Carregar último estado salvo
last_count=0
[[ -f "$STATE_FILE" ]] && last_count=$(cat "$STATE_FILE")

# Salvar novo estado
echo "$count" > "$STATE_FILE"

# --- Construir tooltip com quebras reais ---
if [[ $count -gt 0 ]]; then
    summary="<span color='#7aa2f7'>Pacman: $pacman_count</span> | <span color='#e0af68'>AUR: $aur_count</span> | <span color='#ffffff'>Total: $count</span>"
    tooltip="Atualizações disponíveis:
$summary"

    if [[ $pacman_count -gt 0 ]]; then
        tooltip+="
<span color=\"#00000000\">──────────────</span>
<span color=\"#7aa2f7\">== Pacman ==</span>"
        pacman_trunc=$(echo "$pacman_list" | head -n15 | sed -E \
            "s/^(\S+)\s+(\S+)\s+(\S+)/<span color='#f7768e'>\1<\/span> <span color='#7aa2f7'>\2<\/span> <span color='#9ece6a'>\3<\/span>/")
        tooltip+="
$pacman_trunc"
        [[ $pacman_count -gt 15 ]] && tooltip+="
<span color=\"#565f89\">… e mais $((pacman_count-15)) pacotes</span>"
    fi

    if [[ $aur_count -gt 0 ]]; then
        tooltip+="
<span color=\"#00000000\">──────────────</span>
<span color=\"#e0af68\">== AUR ==</span>"
        aur_trunc=$(echo "$aur_list" | head -n15 | sed -E \
            "s/^(\S+)/<span color='#f7768e'>\1<\/span>/")
        tooltip+="
$aur_trunc"
        [[ $aur_count -gt 15 ]] && tooltip+="
<span color=\"#565f89\">… e mais $((aur_count-15)) pacotes</span>"
    fi
else
    tooltip="Nenhuma atualização disponível"
fi

# --- Notificação só quando muda ---
if [[ $count -gt 0 && $count -ne $last_count ]]; then
    notify-send "Atualizações disponíveis" "$count pacotes aguardando atualização" -i system-software-update
fi

# --- JSON final ---
json=$(jq -nc --arg text "$count" --arg tooltip "$tooltip" \
   '{text: $text, tooltip: $tooltip}')

echo "$json" | tee "$CACHE_JSON"
