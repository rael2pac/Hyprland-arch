# Detectindent plugin for Micro text editor

Whenever a file is opened, the detectindent plugin tries to automatically detect its indentation style (spaces or tabs) and set the `tabstospaces` option accordingly. If spaces indentation is detected, it also tries to detect the indentation width and set the `tabsize` option accordingly.
